# coninput
Go library for input handling using Windows Console API
