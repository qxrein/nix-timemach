package ansi

const (
	// SP is the space character (Char: \x20).
	SP = 0x20
	// DEL is the delete character (Caret: ^?, Char: \x7f).
	DEL = 0x7F
)
